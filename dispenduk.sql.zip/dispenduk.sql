-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 26, 2018 at 01:35 PM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dispenduk`
--

-- --------------------------------------------------------

--
-- Table structure for table `kecamatan`
--

DROP TABLE IF EXISTS `kecamatan`;
CREATE TABLE IF NOT EXISTS `kecamatan` (
  `id_kec` int(11) NOT NULL AUTO_INCREMENT,
  `kec` text NOT NULL,
  `desa` text NOT NULL,
  PRIMARY KEY (`id_kec`)
) ENGINE=MyISAM AUTO_INCREMENT=248 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kecamatan`
--

INSERT INTO `kecamatan` (`id_kec`, `kec`, `desa`) VALUES
(1, 'Ajung', 'Ajung (68175)'),
(2, 'Ajung', 'Klompangan (68175)'),
(3, 'Ajung', 'Mangaran (68175)'),
(4, 'Ajung', 'Pancakarya (68175)'),
(5, 'Ajung', 'Rowo Indah (68175)'),
(6, 'Ajung', 'Sukamakmur (68175)'),
(7, 'Ajung', 'Wirowongso (68175)'),
(8, 'Ambulu', 'Karang Anyar (68132)'),
(9, 'Ambulu', 'Ambulu (68172)'),
(10, 'Ambulu', 'Andongsari (68172)'),
(11, 'Ambulu', 'Pontang (68172)'),
(12, 'Ambulu', 'Sabrang (68172)'),
(13, 'Ambulu', 'Sumberrejo (68172)'),
(14, 'Ambulu', 'Tegalsari (68172)'),
(15, 'Arjasa', 'Arjasa (68191)'),
(16, 'Arjasa', 'Biting (68191)'),
(17, 'Arjasa', 'Candijati (68191)'),
(18, 'Arjasa', 'Darsono (68191)'),
(19, 'Arjasa', 'Kamal (68191)'),
(20, 'Arjasa', 'Kemuningllor (68191)'),
(21, 'Balung', 'Balung Kidul (68161)'),
(22, 'Balung', 'Balung Kulon (68161)'),
(23, 'Balung', 'Balung Lor (68161)'),
(24, 'Balung', 'Curahlele (68161)'),
(25, 'Balung', 'Gumelar (68161)'),
(26, 'Balung', 'Karang Duren (68161)'),
(27, 'Balung', 'Karang Semanding (68161)'),
(28, 'Balung', 'Tutul (68161)'),
(29, 'Bangsalsari', 'Badean (68154)'),
(30, 'Bangsalsari', 'Bangsalsari (68154)'),
(31, 'Bangsalsari', 'Banjarsari (68154)'),
(32, 'Bangsalsari', 'Curah Kalong (68154)'),
(33, 'Bangsalsari', 'Gambirono (68154)'),
(34, 'Bangsalsari', 'Karangsono (68154)'),
(35, 'Bangsalsari', 'Langkap (68154)'),
(36, 'Bangsalsari', 'Petung (68154)'),
(37, 'Bangsalsari', 'Sukorejo (68154)'),
(38, 'Bangsalsari', 'Tisnogambar (68154)'),
(39, 'Bangsalsari', 'Tugusari (68154)'),
(40, 'Gumukmas', 'Bagorejo (68165)'),
(41, 'Gumukmas', 'Gumukmas (68165)'),
(42, 'Gumukmas', 'Karang Rejo (68165)'),
(43, 'Gumukmas', 'Kepanjen (68165)'),
(44, 'Gumukmas', 'Mayangan (68165)'),
(45, 'Gumukmas', 'Menampu (68165)'),
(46, 'Gumukmas', 'Purwoasri (68165)'),
(47, 'Gumukmas', 'Tembokrejo (68165)'),
(48, 'Jelbuk', 'Jelbuk (68192)'),
(49, 'Jelbuk', 'Panduman (68192)'),
(50, 'Jelbuk', 'Suco Pangepok (68192)'),
(51, 'Jelbuk', 'Suger Kidul (68192)'),
(52, 'Jelbuk', 'Suko Jember (68192)'),
(53, 'Jelbuk', 'Sukowiryo (68192)'),
(54, 'Jenggawah', 'Cangkring (68171)'),
(55, 'Jenggawah', 'Jatimulyo (68171)'),
(56, 'Jenggawah', 'Jatisari (68171)'),
(57, 'Jenggawah', 'Jenggawah (68171)'),
(58, 'Jenggawah', 'Kemuning Sari Kidul (68171)'),
(59, 'Jenggawah', 'Kertonegoro (68171)'),
(60, 'Jenggawah', 'Seruni (68171)'),
(61, 'Jenggawah', 'Wonojati (68171)'),
(62, 'Jombang', 'Jombang (68168)'),
(63, 'Jombang', 'Keting (68168)'),
(64, 'Jombang', 'Ngampelrejo (68168)'),
(65, 'Jombang', 'Padomasan (68168)'),
(66, 'Jombang', 'Wringin Agung (68168)'),
(67, 'Kalisat', 'Plalangan (68113)'),
(68, 'Kalisat', 'Ajung (68193)'),
(69, 'Kalisat', 'Gambiran (68193)'),
(70, 'Kalisat', 'Glagahwero (68193)'),
(71, 'Kalisat', 'Gumuksari (68193)'),
(72, 'Kalisat', 'Kalisat (68193)'),
(73, 'Kalisat', 'Patempuran (68193)'),
(74, 'Kalisat', 'Sebanen (68193)'),
(75, 'Kalisat', 'Sukoreno (68193)'),
(76, 'Kalisat', 'Sumber Jeruk (68193)'),
(77, 'Kalisat', 'Sumber Kalong (68193)'),
(78, 'Kalisat', 'Sumber Ketempah (68193)'),
(79, 'Kaliwates', 'Jember Kidul (68131)'),
(80, 'Kaliwates', 'Tegal Besar (68132)'),
(81, 'Kaliwates', 'Kaliwates (68133)'),
(82, 'Kaliwates', 'Sempusari (68135)'),
(83, 'Kaliwates', 'Mangli (68136)'),
(84, 'Kaliwates', 'Kebon Agung (68137)'),
(85, 'Kaliwates', 'Kepatihan (68137)'),
(86, 'Kencong', 'Cakru (68167)'),
(87, 'Kencong', 'Kencong (68167)'),
(88, 'Kencong', 'Kraton (68167)'),
(89, 'Kencong', 'Paseban (68167)'),
(90, 'Kencong', 'Wonorejo (68167)'),
(91, 'Ledokombo', 'Karang Paiton (68196)'),
(92, 'Ledokombo', 'Ledokombo (68196)'),
(93, 'Ledokombo', 'Lembengan (68196)'),
(94, 'Ledokombo', 'Slateng (68196)'),
(95, 'Ledokombo', 'Sukogidri (68196)'),
(96, 'Ledokombo', 'Sumber Anget (68196)'),
(97, 'Ledokombo', 'Sumber Bulus (68196)'),
(98, 'Ledokombo', 'Sumber Lesung (68196)'),
(99, 'Ledokombo', 'Sumber Salak (68196)'),
(100, 'Ledokombo', 'Suren (68196)'),
(101, 'Mayang', 'Tegalrejo (68118)'),
(102, 'Mayang', 'Mayang (68182)'),
(103, 'Mayang', 'Mrawan (68182)'),
(104, 'Mayang', 'Seputih (68182)'),
(105, 'Mayang', 'Sidomukti (68182)'),
(106, 'Mayang', 'Sumber Kejayan (68182)'),
(107, 'Mayang', 'Tegal Waru (68182)'),
(108, 'Mumbulsari', 'Karangkedawung (68174)'),
(109, 'Mumbulsari', 'Kawangrejo (68174)'),
(110, 'Mumbulsari', 'Lampeji (68174)'),
(111, 'Mumbulsari', 'Lengkong (68174)'),
(112, 'Mumbulsari', 'Mumbulsari (68174)'),
(113, 'Mumbulsari', 'Suco (68174)'),
(114, 'Mumbulsari', 'Tamansari (68174)'),
(115, 'Pakusari', 'Bedadung (68181)'),
(116, 'Pakusari', 'Jatian (68181)'),
(117, 'Pakusari', 'Kertosari (68181)'),
(118, 'Pakusari', 'Pakusari (68181)'),
(119, 'Pakusari', 'Patemon (68181)'),
(120, 'Pakusari', 'Subo (68181)'),
(121, 'Pakusari', 'Sumber Pinang (68181)'),
(122, 'Panti', 'Glagahwero (68153)'),
(123, 'Panti', 'Kemiri (68153)'),
(124, 'Panti', 'Kemuningsari Lor (68153)'),
(125, 'Panti', 'Pakis (68153)'),
(126, 'Panti', 'Panti (68153)'),
(127, 'Panti', 'Serut (68153)'),
(128, 'Panti', 'Suci (68153)'),
(129, 'Patrang', 'Patrang (68111)'),
(130, 'Patrang', 'Baratan (68112)'),
(131, 'Patrang', 'Bintoro (68113)'),
(132, 'Patrang', 'Jumerto (68114)'),
(133, 'Patrang', 'Slawu (68116)'),
(134, 'Patrang', 'Gebang (68117)'),
(135, 'Patrang', 'Banjar Sengon (68118)'),
(136, 'Patrang', 'Jember Lor (68118)'),
(137, 'Puger', 'Bagon (68164)'),
(138, 'Puger', 'Grenden (68164)'),
(139, 'Puger', 'Jambearum (68164)'),
(140, 'Puger', 'Kasiyan (68164)'),
(141, 'Puger', 'Kasiyan Timur (68164)'),
(142, 'Puger', 'Mlokorejo (68164)'),
(143, 'Puger', 'Mojomulyo (68164)'),
(144, 'Puger', 'Mojosari (68164)'),
(145, 'Puger', 'Puger Kulon (68164)'),
(146, 'Puger', 'Puger Wetan (68164)'),
(147, 'Puger', 'Wonosari (68164)'),
(148, 'Puger', 'Wringin Telu (68164)'),
(149, 'Rambipuji', 'Curahmalang (68152)'),
(150, 'Rambipuji', 'Gugut (68152)'),
(151, 'Rambipuji', 'Kaliwining (68152)'),
(152, 'Rambipuji', 'Nogosari (68152)'),
(153, 'Rambipuji', 'Pecoro (68152)'),
(154, 'Rambipuji', 'Rambigundam (68152)'),
(155, 'Rambipuji', 'Rambipuji (68152)'),
(156, 'Rambipuji', 'Rowotamtu (68152)'),
(157, 'Semboro', 'Pondok Dalem (68157)'),
(158, 'Semboro', 'Pondok Joyo (68157)'),
(159, 'Semboro', 'Rejo Agung (68157)'),
(160, 'Semboro', 'Semboro (68157)'),
(161, 'Semboro', 'Sidomekar (68157)'),
(162, 'Semboro', 'Sidomulyo (68157)'),
(163, 'Silo', 'Garahan (68184)'),
(164, 'Silo', 'Harjomolyo (68184)'),
(165, 'Silo', 'Karangharjo (68184)'),
(166, 'Silo', 'Mulyorejo (68184)'),
(167, 'Silo', 'Pace (68184)'),
(168, 'Silo', 'Sempolan (68184)'),
(169, 'Silo', 'Sidomulyo (68184)'),
(170, 'Silo', 'Silo (68184)'),
(171, 'Silo', 'Sumberjati (68184)'),
(172, 'Sukorambi', 'Dukuh Mencek (68151)'),
(173, 'Sukorambi', 'Jubung (68151)'),
(174, 'Sukorambi', 'Karangpring (68151)'),
(175, 'Sukorambi', 'Kelungkung (68151)'),
(176, 'Sukorambi', 'Sukorambi (68151)'),
(177, 'Sukowono', 'Arjasa (68194)'),
(178, 'Sukowono', 'Balet Baru (68194)'),
(179, 'Sukowono', 'Dawuhan Mangli (68194)'),
(180, 'Sukowono', 'Mojogeni (68194)'),
(181, 'Sukowono', 'Pocangan (68194)'),
(182, 'Sukowono', 'Sukokerto (68194)'),
(183, 'Sukowono', 'Sukorejo (68194)'),
(184, 'Sukowono', 'Sukosari (68194)'),
(185, 'Sukowono', 'Sukowono (68194)'),
(186, 'Sukowono', 'Sumber Wringin (68194)'),
(187, 'Sukowono', 'Sumberdanti (68194)'),
(188, 'Sukowono', 'Sumberwaru (68194)'),
(189, 'SumberBaru', 'Gelang (68156)'),
(190, 'SumberBaru', 'Jambesari (68156)'),
(191, 'SumberBaru', 'Jamintoro (68156)'),
(192, 'SumberBaru', 'Jatiroto (68156)'),
(193, 'SumberBaru', 'Kaliglagah (68156)'),
(194, 'SumberBaru', 'Karang Bayat (68156)'),
(195, 'SumberBaru', 'Pringgowirawan (68156)'),
(196, 'SumberBaru', 'Rowo Tengah (68156)'),
(197, 'SumberBaru', 'Sumber Agung (68156)'),
(198, 'SumberBaru', 'Yosorati (68156)'),
(199, 'SumberJambe', 'Cumedak (68195)'),
(200, 'SumberJambe', 'Gunung Malang (68195)'),
(201, 'SumberJambe', 'Jambe Arum (68195)'),
(202, 'SumberJambe', 'Plereyan (68195)'),
(203, 'SumberJambe', 'Pringgondani (68195)'),
(204, 'SumberJambe', 'Randu Agung (68195)'),
(205, 'SumberJambe', 'Rowosari (68195)'),
(206, 'SumberJambe', 'Sumber Pakem (68195)'),
(207, 'SumberJambe', 'Sumberjambe (68195)'),
(208, 'SumberSari', 'Sumbersari (68121)'),
(209, 'SumberSari', 'Kebonsari (68122)'),
(210, 'SumberSari', 'Karangrejo (68124)'),
(211, 'SumberSari', 'Tegal Gede (68124)'),
(212, 'SumberSari', 'Wirolegi (68124)'),
(213, 'SumberSari', 'Antirogo (68125)'),
(214, 'SumberSari', 'Keranjingan (68126)'),
(215, 'Tanggul', 'Darungan (68155)'),
(216, 'Tanggul', 'Klatakan (68155)'),
(217, 'Tanggul', 'Kramat Sukoharjo (68155)'),
(218, 'Tanggul', 'Manggisan (68155)'),
(219, 'Tanggul', 'Patemon (68155)'),
(220, 'Tanggul', 'Selodakon (68155)'),
(221, 'Tanggul', 'Tanggul Kulon (68155)'),
(222, 'Tanggul', 'Tanggul Wetan (68155)'),
(223, 'Tempurejo', 'Andongrejo (68173)'),
(224, 'Tempurejo', 'Curahnongko (68173)'),
(225, 'Tempurejo', 'Curahtakir (68173)'),
(226, 'Tempurejo', 'Pondokrejo (68173)'),
(227, 'Tempurejo', 'Sanenrejo (68173)'),
(228, 'Tempurejo', 'Sidodadi (68173)'),
(229, 'Tempurejo', 'Tempurejo (68173)'),
(230, 'Tempurejo', 'Wonoasri (68173)'),
(231, 'Umbulsari', 'Gadingrejo (68166)'),
(232, 'Umbulsari', 'Gunungsari (68166)'),
(233, 'Umbulsari', 'Mundurejo (68166)'),
(234, 'Umbulsari', 'Paleran (68166)'),
(235, 'Umbulsari', 'Sidorejo (68166)'),
(236, 'Umbulsari', 'Sukoreno (68166)'),
(237, 'Umbulsari', 'Tanjungsari (68166)'),
(238, 'Umbulsari', 'Tegal Wangi (68166)'),
(239, 'Umbulsari', 'Umbulrejo (68166)'),
(240, 'Umbulsari', 'Umbulsari (68166)'),
(241, 'Wuluhan', 'Ampel (68162)'),
(242, 'Wuluhan', 'Dukuh Dempok (68162)'),
(243, 'Wuluhan', 'Glundengan (68162)'),
(244, 'Wuluhan', 'Kesilir (68162)'),
(245, 'Wuluhan', 'Lojejer (68162)'),
(246, 'Wuluhan', 'Tamansari (68162)'),
(247, 'Wuluhan', 'Tanjung Rejo (68162)');

-- --------------------------------------------------------

--
-- Table structure for table `kia`
--

DROP TABLE IF EXISTS `kia`;
CREATE TABLE IF NOT EXISTS `kia` (
  `id_reg` varchar(99) NOT NULL,
  `nik_anak` text NOT NULL,
  `nama` text NOT NULL,
  `tempat_lahir` text NOT NULL,
  `tgl_lahir` date NOT NULL,
  `jk` varchar(1) NOT NULL,
  `nkk` text NOT NULL,
  `nama_kk` text NOT NULL,
  `no_akta` text NOT NULL,
  `agama` text NOT NULL,
  `kewarganegaraan` text NOT NULL,
  `alamat` text NOT NULL,
  `rt` text NOT NULL,
  `rw` text NOT NULL,
  `kecamatan` text NOT NULL,
  `kelurahan` text NOT NULL,
  `upload_kk` text NOT NULL,
  `upload_akta` text NOT NULL,
  `ktp_ortu` text NOT NULL,
  `pas_foto` text NOT NULL,
  `ket` text NOT NULL,
  PRIMARY KEY (`id_reg`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kia`
--

INSERT INTO `kia` (`id_reg`, `nik_anak`, `nama`, `tempat_lahir`, `tgl_lahir`, `jk`, `nkk`, `nama_kk`, `no_akta`, `agama`, `kewarganegaraan`, `alamat`, `rt`, `rw`, `kecamatan`, `kelurahan`, `upload_kk`, `upload_akta`, `ktp_ortu`, `pas_foto`, `ket`) VALUES
('8E13B1AB', '1234567890111111', 'Anakku', 'Jember', '2018-08-07', 'P', '1234567890123456', 'Halo', '1111222233334444', 'islam', 'Indonesia', 'Dusun oro oro', '1', '1', 'Silo', 'Sempolan', 'img/pict1.png', 'img/pict2.jpg', 'img/pict4.jpg', 'img/pict3.jpg', ''),
('C8CC204E', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `kkbaru`
--

DROP TABLE IF EXISTS `kkbaru`;
CREATE TABLE IF NOT EXISTS `kkbaru` (
  `id_reg` varchar(99) NOT NULL,
  `kk` text NOT NULL,
  `nik` text NOT NULL,
  `nama` text NOT NULL,
  `sk` text NOT NULL,
  `ktp` text NOT NULL,
  `f101` text NOT NULL,
  `ket` text NOT NULL,
  PRIMARY KEY (`id_reg`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kkbaru`
--

INSERT INTO `kkbaru` (`id_reg`, `kk`, `nik`, `nama`, `sk`, `ktp`, `f101`, `ket`) VALUES
('EC625F7F', '1234567890123456', '1234567890987654', 'halo', 'img/P_20180123_210235_SRES.jpg', 'img/P_20180123_210303_SRES.jpg', 'img/P_20180123_210225_SRES.jpg', ''),
('2B8340C3', '1234567811111111', '1234567887654321', 'Warga Baru', 'img/pict1.png', 'img/pict2.jpg', 'img/pict10.jpg', ''),
('6CB22C56', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `lahir_administrasi`
--

DROP TABLE IF EXISTS `lahir_administrasi`;
CREATE TABLE IF NOT EXISTS `lahir_administrasi` (
  `id_reg` varchar(99) NOT NULL,
  `surat_kelahiran` text NOT NULL,
  `ktp_saksi` text NOT NULL,
  `kk_ortu` text NOT NULL,
  `ktp_ortu` text NOT NULL,
  `akta_nikah` text NOT NULL,
  `sptjm_lahir` text NOT NULL,
  `sptjm_pasangan` text NOT NULL,
  `no_hp` varchar(13) NOT NULL,
  `ket` text NOT NULL,
  PRIMARY KEY (`id_reg`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lahir_administrasi`
--

INSERT INTO `lahir_administrasi` (`id_reg`, `surat_kelahiran`, `ktp_saksi`, `kk_ortu`, `ktp_ortu`, `akta_nikah`, `sptjm_lahir`, `sptjm_pasangan`, `no_hp`, `ket`) VALUES
('D72727EF', 'img/gbr1.png', 'img/gbr2.png', 'img/gbr3.png', 'img/gbr11.png', 'img/gbr12.png', 'img/gbr13.png', 'img/gbr14.png', '081230856890', ''),
('6863FE19', 'img/mh.jpg', 'img/', 'img/', 'img/', 'img/', 'img/', 'img/', '081333444555', '');

-- --------------------------------------------------------

--
-- Table structure for table `lahir_bapak`
--

DROP TABLE IF EXISTS `lahir_bapak`;
CREATE TABLE IF NOT EXISTS `lahir_bapak` (
  `id_reg` varchar(99) NOT NULL,
  `nik_bapak` text NOT NULL,
  `nama` text NOT NULL,
  `tgl_lahir` date NOT NULL,
  `kerja` text NOT NULL,
  `alamat` text NOT NULL,
  `rt` text NOT NULL,
  `rw` text NOT NULL,
  `kecamatan` text NOT NULL,
  `kelurahan` text NOT NULL,
  `kewarganegaraan` text NOT NULL,
  `kebangsaan` text NOT NULL,
  `tgl_kawin` date NOT NULL,
  `ket` text NOT NULL,
  PRIMARY KEY (`id_reg`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lahir_bapak`
--

INSERT INTO `lahir_bapak` (`id_reg`, `nik_bapak`, `nama`, `tgl_lahir`, `kerja`, `alamat`, `rt`, `rw`, `kecamatan`, `kelurahan`, `kewarganegaraan`, `kebangsaan`, `tgl_kawin`, `ket`) VALUES
('D72727EF', '1234567887654321', 'Warga Baru', '1977-12-27', 'TNI', 'Jember', '1', '10', 'Pakusari', 'Sumber', 'Indonesia', 'Indonesia', '1999-01-01', ''),
('6863FE19', '1234876512348765', 'Bapak Tabung', '1966-11-01', 'Petani', 'Jl. Poros', '001', '004', 'Umbulsari', 'Sukoreno', 'Indonesia', 'Indonesia', '2017-01-30', '');

-- --------------------------------------------------------

--
-- Table structure for table `lahir_bayi`
--

DROP TABLE IF EXISTS `lahir_bayi`;
CREATE TABLE IF NOT EXISTS `lahir_bayi` (
  `id_reg` varchar(99) NOT NULL,
  `nik_bayi` varchar(16) NOT NULL,
  `nama` text NOT NULL,
  `jk` varchar(1) NOT NULL,
  `tempat_dilahirkan` text NOT NULL,
  `tempat_lahir` text NOT NULL,
  `tgl_lahir` date NOT NULL,
  `waktu` time NOT NULL,
  `jenis_lahir` text NOT NULL,
  `lahir_ke` int(2) NOT NULL,
  `penolong` text NOT NULL,
  `berat` int(11) NOT NULL,
  `panjang` int(11) NOT NULL,
  `nkk` varchar(16) NOT NULL,
  `nama_kk` text NOT NULL,
  `ket` text NOT NULL,
  PRIMARY KEY (`id_reg`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lahir_bayi`
--

INSERT INTO `lahir_bayi` (`id_reg`, `nik_bayi`, `nama`, `jk`, `tempat_dilahirkan`, `tempat_lahir`, `tgl_lahir`, `waktu`, `jenis_lahir`, `lahir_ke`, `penolong`, `berat`, `panjang`, `nkk`, `nama_kk`, `ket`) VALUES
('6863FE19', '1010123456780001', 'Bayi Dobol Ladde', 'L', 'Puskesmas', 'Selayar', '2018-07-02', '05:30:00', 'Tunggal', 1, 'Bidan', 3, 55, '1234567890123456', 'Pak Tabung', ''),
('D72727EF', '', 'Bayikuuuu', 'L', 'Puskesmas', 'Jember', '2018-09-08', '12:12:12', 'tunggal', 1, 'Suster ngesot', 3, 35, '1234567811111111', 'Warga Baru', '');

-- --------------------------------------------------------

--
-- Table structure for table `lahir_ibu`
--

DROP TABLE IF EXISTS `lahir_ibu`;
CREATE TABLE IF NOT EXISTS `lahir_ibu` (
  `id_reg` varchar(99) NOT NULL,
  `nik_ibu` varchar(16) NOT NULL,
  `nama` text NOT NULL,
  `tgl_lahir` date NOT NULL,
  `kerja` text NOT NULL,
  `alamat` text NOT NULL,
  `rt` text NOT NULL,
  `rw` text NOT NULL,
  `kecamatan` text NOT NULL,
  `kelurahan` text NOT NULL,
  `kewarganegaraan` text NOT NULL,
  `kebangsaan` text NOT NULL,
  `tgl_kawin` text NOT NULL,
  `ket` text NOT NULL,
  PRIMARY KEY (`id_reg`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lahir_ibu`
--

INSERT INTO `lahir_ibu` (`id_reg`, `nik_ibu`, `nama`, `tgl_lahir`, `kerja`, `alamat`, `rt`, `rw`, `kecamatan`, `kelurahan`, `kewarganegaraan`, `kebangsaan`, `tgl_kawin`, `ket`) VALUES
('D72727EF', '1234567801010101', 'Ibu X', '1988-12-12', 'Wiraswasta', 'Jember', '1', '99', 'Pakusari', 'Sumber', 'Indonesia', 'Indonesia', '1999-01-01', ''),
('6863FE19', '1234567890987654', 'Halo', '1973-12-11', 'Ibu Rumah Tangga', 'jalan pintas', '100', '500', 'Silo', 'Silo', 'Indonesia', 'Indonesia', '2017-01-30', '');

-- --------------------------------------------------------

--
-- Table structure for table `lahir_saksi1`
--

DROP TABLE IF EXISTS `lahir_saksi1`;
CREATE TABLE IF NOT EXISTS `lahir_saksi1` (
  `id_reg` varchar(99) NOT NULL,
  `nik_saksi1` varchar(16) NOT NULL,
  `nama` text NOT NULL,
  `umur` int(2) NOT NULL,
  `jk` varchar(1) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `kerja` text NOT NULL,
  `alamat` text NOT NULL,
  `rt` text NOT NULL,
  `rw` text NOT NULL,
  `kecamatan` text NOT NULL,
  `kelurahan` text NOT NULL,
  `ket` text NOT NULL,
  PRIMARY KEY (`id_reg`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lahir_saksi1`
--

INSERT INTO `lahir_saksi1` (`id_reg`, `nik_saksi1`, `nama`, `umur`, `jk`, `tgl_lahir`, `kerja`, `alamat`, `rt`, `rw`, `kecamatan`, `kelurahan`, `ket`) VALUES
('D72727EF', '1234567812121212', 'Saksi Mata 1', 50, 'P', '1968-08-08', 'Ibu Rumah Tangga', 'Jember', '5', '55', 'Mayang', 'Mrawan', ''),
('6863FE19', '0101020203030404', 'Wong Ndelok', 50, 'L', '1968-08-01', 'Buruh Tani', 'jauh sekali', '12', '12', 'Jombang', 'Keting', '');

-- --------------------------------------------------------

--
-- Table structure for table `lahir_saksi2`
--

DROP TABLE IF EXISTS `lahir_saksi2`;
CREATE TABLE IF NOT EXISTS `lahir_saksi2` (
  `id_reg` varchar(99) NOT NULL,
  `nik_saksi2` varchar(16) NOT NULL,
  `nama` text NOT NULL,
  `umur` int(2) NOT NULL,
  `jk` varchar(1) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `kerja` text NOT NULL,
  `alamat` text NOT NULL,
  `rt` text NOT NULL,
  `rw` text NOT NULL,
  `kecamatan` text NOT NULL,
  `kelurahan` text NOT NULL,
  `ket` text NOT NULL,
  PRIMARY KEY (`id_reg`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lahir_saksi2`
--

INSERT INTO `lahir_saksi2` (`id_reg`, `nik_saksi2`, `nama`, `umur`, `jk`, `tgl_lahir`, `kerja`, `alamat`, `rt`, `rw`, `kecamatan`, `kelurahan`, `ket`) VALUES
('D72727EF', '1234567821212121', 'Ibu Warga Situ', 40, 'P', '1978-08-08', 'Makelar', 'Jember', '9', '19', 'Tempurejo', 'Curahtakir', ''),
('6863FE19', '1111222233334444', 'Wong Liwat', 30, 'P', '1988-06-14', 'PNS', 'Depan Kantor Pemda', '011', '011', 'Kalisat', 'Kalisat', '');

-- --------------------------------------------------------

--
-- Table structure for table `permohonan`
--

DROP TABLE IF EXISTS `permohonan`;
CREATE TABLE IF NOT EXISTS `permohonan` (
  `id_reg` varchar(99) NOT NULL,
  `tanggal` date NOT NULL,
  `nik_pemohon` text NOT NULL,
  `nama_pemohon` text NOT NULL,
  `jenis` text NOT NULL,
  `id_status` varchar(99) NOT NULL,
  `ket` text NOT NULL,
  PRIMARY KEY (`id_reg`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `permohonan`
--

INSERT INTO `permohonan` (`id_reg`, `tanggal`, `nik_pemohon`, `nama_pemohon`, `jenis`, `id_status`, `ket`) VALUES
('EC625F7F', '2018-07-14', '1234567890987654', 'halo', 'Permohonan Pencetakan KK Baru', 'BD14408E', ''),
('6863FE19', '2018-07-09', '1234567890987654', 'halo', 'Permohonan Pembuatan Akte Kelahiran', 'A99DBAA7', ''),
('49FBAA08', '2018-07-25', '1234567890987654', 'halo', 'Pengaduan Online', '93DAC02F', ''),
('8E13B1AB', '2018-08-07', '1234567890987654', 'halo', 'Permohonan Pembuatan/Pencetakan KIA', '4E61F5D3', ''),
('D72727EF', '2018-08-08', '1234567887654321', 'Warga Baru', 'Permohonan Pembuatan Akte Kelahiran', 'A60A6791', ''),
('2B8340C3', '2018-08-08', '1234567887654321', 'Warga Baru', 'Permohonan Pencetakan KK Baru', 'D6E292E4', ''),
('C8CC204E', '2018-08-08', '1234567887654321', 'Warga Baru', 'Permohonan Pembuatan/Pencetakan KIA', '', ''),
('BA6D4A58', '2018-08-08', '1234567887654321', 'Warga Baru', 'Pengaduan Online', '51C324E5', ''),
('6CB22C56', '2018-08-20', '1234567887654321', 'Warga Baru', 'Permohonan Pencetakan KK Baru', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `p_online`
--

DROP TABLE IF EXISTS `p_online`;
CREATE TABLE IF NOT EXISTS `p_online` (
  `id_reg` varchar(99) NOT NULL,
  `nik` text NOT NULL,
  `nama` text NOT NULL,
  `subjek` text NOT NULL,
  `uraian` text NOT NULL,
  `waktu` timestamp NOT NULL,
  `bukti1` text NOT NULL,
  `bukti2` text NOT NULL,
  `bukti3` text NOT NULL,
  `ket` text NOT NULL,
  PRIMARY KEY (`id_reg`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `p_online`
--

INSERT INTO `p_online` (`id_reg`, `nik`, `nama`, `subjek`, `uraian`, `waktu`, `bukti1`, `bukti2`, `bukti3`, `ket`) VALUES
('49FBAA08', '1234567890987654', 'halo', 'Proses Pelayanan yg lama', 'Lama banget', '2018-07-25 07:23:37', 'img/Wallpaper_gaptech_4K.jpg', 'img/Wallpaper_gaptech_219.jpg', 'img/ahaha.jpg', ''),
('BA6D4A58', '1234567887654321', 'Warga Baru', 'Lamaaaaa', 'Luaaaamaaaaaaaa pooll', '2018-08-08 08:15:42', 'img/pict16.jpg', 'img/', 'img/', '');

-- --------------------------------------------------------

--
-- Table structure for table `reply`
--

DROP TABLE IF EXISTS `reply`;
CREATE TABLE IF NOT EXISTS `reply` (
  `id_reply` varchar(99) NOT NULL,
  `id_reg` varchar(99) NOT NULL,
  `waktu` timestamp NOT NULL,
  `uraian` text NOT NULL,
  `role` text NOT NULL,
  `ket` text NOT NULL,
  PRIMARY KEY (`id_reply`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reply`
--

INSERT INTO `reply` (`id_reply`, `id_reg`, `waktu`, `uraian`, `role`, `ket`) VALUES
('A73EEA06', '49FBAA08', '2018-07-26 07:47:28', 'Bagaimana ini admin kenapa belum di respon juga', 'USER', ''),
('A3B2BC13', '49FBAA08', '2018-07-28 08:48:22', 'Mohon bersabar ini ujian', 'ADMIN', ''),
('9E9C87B4', '49FBAA08', '2018-08-03 07:16:43', 'iya iya', 'USER', ''),
('DCE066D9', '49FBAA08', '2018-08-03 07:19:45', 'Saya selalu berdoa', 'USER', ''),
('461F6F8A', 'BA6D4A58', '2018-08-08 08:28:45', 'Sabar ngapa', 'ADMIN', '');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

DROP TABLE IF EXISTS `status`;
CREATE TABLE IF NOT EXISTS `status` (
  `id_status` varchar(99) NOT NULL,
  `id_reg` varchar(99) NOT NULL,
  `tgl_status` timestamp NOT NULL,
  `status` text NOT NULL,
  `ket` text NOT NULL,
  PRIMARY KEY (`id_status`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id_status`, `id_reg`, `tgl_status`, `status`, `ket`) VALUES
('BD14408E', 'EC625F7F', '2018-07-15 04:25:34', 'Finalisasi', 'Permohonan Terkirim.'),
('A99DBAA7', '6863FE19', '2018-07-12 13:16:57', 'Finalisasi', 'Permohonan Terkirim.'),
('AAEE3F26', '6863FE19', '2018-07-13 11:47:56', 'masih proses', 'tunggu status berikutnya'),
('4267B5CC', '49FBAA08', '2018-07-31 16:07:13', 'On Progress', 'Mohon Bersabar ini Ujian'),
('93DAC02F', '49FBAA08', '2018-07-25 14:44:31', 'Finalisasi', 'Permohonan Terkirim.'),
('46EB8F6C', '6863FE19', '2018-07-24 13:26:16', 'Pencetakan', 'Akta sedang dicetak'),
('0E86523C', '49FBAA08', '2018-08-02 13:19:45', 'Menunggu Persetujuan', 'menunggu acc kacab'),
('05CD74A9', '49FBAA08', '2018-08-02 13:28:21', 'END', 'Permohonan Selesai'),
('39439123', '6863FE19', '2018-08-02 13:35:57', 'Tercetak', 'Sudah bisa diambil'),
('951A413A', '6863FE19', '2018-08-02 13:36:03', 'END', 'Permohonan Selesai'),
('4E61F5D3', '8E13B1AB', '2018-08-07 14:29:20', 'Finalisasi', 'Permohonan Terkirim.'),
('D6E292E4', '2B8340C3', '2018-08-20 14:15:05', 'END', 'Permohonan Selesai'),
('E7B68525', '2B8340C3', '2018-08-08 14:58:46', 'Finalisasi', 'Permohonan Terkirim.'),
('51C324E5', 'BA6D4A58', '2018-08-08 15:16:09', 'Finalisasi', 'Permohonan Terkirim.'),
('8960472A', 'BA6D4A58', '2018-08-08 15:29:04', 'Proses', 'Iya iya'),
('4351BCB8', '2B8340C3', '2018-08-20 13:42:54', 'On Progress', 'Masih dicetak'),
('4A82092D', '2B8340C3', '2018-08-20 13:43:21', 'Hampir', 'Lusa bisa diambil'),
('A60A6791', 'D72727EF', '2018-08-26 12:43:15', 'Finalisasi', 'Permohonan Terkirim.');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id_user` varchar(99) NOT NULL,
  `nama` text NOT NULL,
  `nkk` varchar(16) NOT NULL,
  `nik` varchar(16) NOT NULL,
  `tempat_lahir` text NOT NULL,
  `tgl_lahir` date NOT NULL,
  `jk` varchar(1) NOT NULL,
  `kecamatan` text NOT NULL,
  `kelurahan` text NOT NULL,
  `alamat` text NOT NULL,
  `rt` text NOT NULL,
  `rw` text NOT NULL,
  `email` text NOT NULL,
  `password` varchar(99) NOT NULL,
  `confirm` varchar(99) NOT NULL,
  `hp1` text NOT NULL,
  `hp2` text NOT NULL,
  `scan_kk` text NOT NULL,
  `scan_ktp` text NOT NULL,
  `foto_profil` text NOT NULL,
  `role` varchar(20) NOT NULL,
  `status` int(1) NOT NULL,
  `tgl_register` date NOT NULL,
  `ket` text NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama`, `nkk`, `nik`, `tempat_lahir`, `tgl_lahir`, `jk`, `kecamatan`, `kelurahan`, `alamat`, `rt`, `rw`, `email`, `password`, `confirm`, `hp1`, `hp2`, `scan_kk`, `scan_ktp`, `foto_profil`, `role`, `status`, `tgl_register`, `ket`) VALUES
('F10BCD0C', 'Syaikhu Rizal', '3509022209160001', '3509021307990002', 'Jember', '1999-07-13', 'L', 'Kencong', 'Wonorejo', 'Jl. Mayjen Suparman, Dusun Krajan C', '004', '025', 'permanen29@gmail.com', 'c93ccd78b2076528346216b3b2f701e6', 'admin1234', '081230856890', '', 'img/pict17.png', 'img/pict18.png', 'img/pict19.png', 'ADMIN', 1, '2018-08-20', ''),
('76E48654', 'Mila Dwi Agustin', '3509032210150009', '3509030708980009', 'Palembang', '1998-08-07', 'P', 'Patrang', 'Patrang', 'Jl. Raya Gumukmas Menampu', '002', '022', 'sspvsyaikhu@gmail.com', 'c93ccd78b2076528346216b3b2f701e6', 'admin1234', '01230456789', '08298765423', 'img/', 'img/', 'img/', 'USER', 1, '2018-08-02', ''),
('013402F1', 'halo', '1234567890123456', '1234567890987654', 'Makassar', '2000-06-26', 'P', 'SumberBaru', 'Yosorati', 'Jl. Perintis kemerdekaan', '001', '002', 'halomakassar@gmail.com', '181105a73fc52365ed0d0d7216d3adfa', 'huhuhuhu', '081111222333', '082222333444', 'img/laptop_kantor.png', 'img/mylaptop.png', 'img/pict6.jpg', 'USER', 1, '2018-08-10', ''),
('EE6B9C7D', 'Warga Baru', '1234567811111111', '1234567887654321', 'Jember', '1977-12-27', 'L', 'Pakusari', 'Sumber', 'Dusun Lalu', '1', '10', 'abalabalsayang@gmail.com', '9a1f8c1479e35ac3599344564cc46c8d', 'abalabalsayang', '018230856890', '088112223333', 'img/pict20.png', 'img/pict21.png', 'img/pict8.jpg', 'USER', 1, '2018-08-08', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
